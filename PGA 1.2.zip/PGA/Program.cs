﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using PGA;
namespace ConsoleApp1
{
    internal class Program
    {
        
        private static Int64 Sums = 0;
        public static char[] v1;
        private static void Main(string[] args)
        {

        Console:
            Console.Clear();
            Console.Title = "PGA HASH FUNCTION DEVELOPED BY MR. TOURAJ OSTOVARI AND MR. SAEED SHIRVANI";
            Console.ForegroundColor = ConsoleColor.White;
            Console.Write("Default value HashJKLM\n");
            Console.ForegroundColor = ConsoleColor.Green;
            Console.Write("Write your string:\r\n");
            //v1 = Encoding.UTF8.GetChars(System.IO.File.ReadAllBytes(args[0].ToString()));
            v1 = Console.ReadLine().ToCharArray();

            Stopwatch st = new Stopwatch();
            st.Start();

            foreach (char item in v1)
            {
                Sums += (int)item;
                PGA.Linear_congruential_generator.LCG((long)Math.Pow(v1[0], 2), item, Sums);
            }


            List<String> list = new List<String>();

            foreach (uint item in v1)
            {
                string temp_hex = Convert.ToString(item, 16);
                if (temp_hex.Contains("a") || temp_hex.Contains("b") || temp_hex.Contains("c") ||
                    temp_hex.Contains("d") || temp_hex.Contains("e") || temp_hex.Contains("f"))
                {
                    temp_hex = safe_zone.Safe_Hex(temp_hex);
                }

                list.Add(Convert.ToString(int.Parse(temp_hex), 2));
            }
            /*

            Below Code Reverses the string

            */
            for (int i = 0; i < list.Count; i += 1)
            {

                string gg = list[i].ToString();
                string temp_reverse = "";
                for (int i2 = gg.Count() - 1; i2 >= 0; i2--)
                {
                    temp_reverse += gg[i2];
                }
                list[i] = temp_reverse;
                Console.WriteLine("Reverse : \n"+temp_reverse);
            }

            /*
             
            Below Code Does XOR Do be Do az array yek shoro mishe

             */
            System.Collections.Generic.List<String> list3 = new List<String>();
                for (int i = 1; i < list.Count; i += 2)
                {
                    dynamic temp1 = long.Parse(list[i]);
                    dynamic temp2 = long.Parse(list[i - 1]);
                    temp1 = temp1 ^ temp2;
                    list3.Add(Convert.ToString(temp1,2));
                    Console.WriteLine("XOR DO BE DO\n" + temp1);
                }


            /*

            Below Code does Notter az array 0 shoro mishe

             */
            for (int i = 0; i < list.Count; i += 2)
            {
                Int64 temp = Convert.ToInt64(Notter(list[i]));
                list3.Add(Convert.ToString(temp, 2));
                Console.WriteLine("Notter\n"+temp);

            }


            /*
             Below Code does custome supplement
             */
            for (int i = 0; i < list3.Count; i += 1)
            {
                Int64 temp = Convert.ToInt64(Supplement_two(list[i]),2);


                list3[i] = Convert.ToString((temp ^ (2*Sums-1)), 10);
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("Sup: "+ temp + "  supplement :"+ (temp^Sums).ToString());
            }



            /*
             * XOR WITH NUMBER GENERATOR
             */
            {
                int i = 0;
                    for (; i < list3.Count; i++)
                    {
                        list3[i] = Convert.ToString(Int64.Parse(list3[i]) ^ PGA.Linear_congruential_generator.lst[i], 2);
                    }
                    //if (ex.Message == "Value was either too large or too small for an Int64.") { goto Show; } 
            }
            
            Show:
            // SHowing the result
            Console.ForegroundColor = ConsoleColor.Green;
            string res = "";
            for (int i = 0; i < list3.Count; i++)
            {
                Console.WriteLine(Convert.ToInt64(list3[i], 2).ToString("X"));
                res += Convert.ToInt64(list3[i], 2).ToString("X");
            }
            st.Stop();
            Console.WriteLine($"Hash: {res}");
            Console.ForegroundColor = ConsoleColor.Red;

            Console.WriteLine("Stopwatch:" + st.Elapsed);
            Console.ReadLine();
            Sums = 0;
            Linear_congruential_generator.lst.Clear();
            goto Console;
        }

        private static string Notter(string bin)
        {
            StringBuilder sb = new StringBuilder(bin);
            for (int i = 0; i < bin.Length; i++)
            {
                if (sb[i] == '0')
                {
                    sb[i] = '1';
                }
                else
                {
                    sb[i] = '0';
                }
            }

            return sb.ToString();
        }

        private static string Supplement_two(string bin)
        {
            bool first_time = true;
            StringBuilder sb = new StringBuilder(bin);
            for (int i = 0; i < bin.Length; i++)
            {
                if (sb[i] == '1')
                {

                    if (first_time == false)
                        sb[i] = '0';
                    if (first_time == true) { first_time = false; } else { first_time = true; }
                }
                else
                {
                    sb[i] = '1';
                }
            }

            return sb.ToString();
        }
    }

    internal static class safe_zone
    {
        private enum Hex_Box
        {
            a = 67,
            b = 52,
            c = 37,
            d = 61,
            e = 82,
            f = 75,
        }

        public static string Safe_Hex(string Text)
        {
            if (Text.Contains("a") || Text.Contains("A"))
            {
                string temp = Convert.ToString((int)Hex_Box.a);
                Text = Text.Replace("a", temp);
                Text = Text.Replace("A", temp);
            }

            if (Text.Contains("b") || Text.Contains("B"))
            {
                string temp = Convert.ToString((int)Hex_Box.b);
                Text = Text.Replace("b", temp);
                Text = Text.Replace("B", temp);
            }

            if (Text.Contains("c") || Text.Contains("C"))
            {
                string temp = Convert.ToString((int)Hex_Box.c);
                Text = Text.Replace("c", temp);
                Text = Text.Replace("C", temp);
            }

            if (Text.Contains("d") || Text.Contains("D"))
            {
                string temp = Convert.ToString((int)Hex_Box.d);
                Text = Text.Replace("d", temp);
                Text = Text.Replace("D", temp);
            }

            if (Text.Contains("e") || Text.Contains("E"))
            {
                string temp = Convert.ToString((int)Hex_Box.e);
                Text = Text.Replace("e", temp);
                Text = Text.Replace("E", temp);
            }

            if (Text.Contains("f") || Text.Contains("F"))
            {
                string temp = Convert.ToString((int)Hex_Box.f);
                Text = Text.Replace("f", temp);
                Text = Text.Replace("F", temp);
            }

            return Text;
        }
    }
}