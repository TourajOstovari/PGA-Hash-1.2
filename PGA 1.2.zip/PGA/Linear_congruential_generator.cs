﻿using System;
using System.Collections.Generic;

namespace PGA
{
    public class Linear_congruential_generator
    {
        public static List<Int64> lst = new List<Int64>();
        public static void LCG(Int64 a, Int64 Xi, Int64 c)
        {
            Int64 m = Xi + c;
            int timer = 0;
            Int64 temp = 0;
            while (Linear_congruential_generator.lst.Count <= ConsoleApp1.Program.v1.Length)
            {
                temp = Int64.Parse((a * Xi + c).ToString()) % m;
                Xi = temp;
                if (lst.Contains(temp))
                {
                    m = (long)Math.Pow((Xi + c), 2);
                    timer++;
                    if (timer == 50)
                    {
                        break;
                    }

                }

                if (!lst.Contains(temp))
                {
                    lst.Add(temp);
                    timer = 0;
                }

            }
        }
    }
}
